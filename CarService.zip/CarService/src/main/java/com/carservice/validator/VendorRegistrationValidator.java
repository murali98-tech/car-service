package com.carservice.validator;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.carservice.model.VendorRegistration;
@Service
public class VendorRegistrationValidator implements Validator {

	@Override
	public boolean supports(Class<?> vendorreg) {
		return VendorRegistration.class.equals(vendorreg);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
     VendorRegistration vendorreg = (VendorRegistration)target;
		
		
		if(!(vendorreg.getFirstName().length() > 2 && vendorreg.getFirstName().length()<32)||(!vendorreg.getFirstName().matches("[a-zA-Z ]+"))) {
			errors.rejectValue("firstName", null, "Enter Valid First Name");
		}
		
		
		
		if(!(vendorreg.getLastName().length() >0 && vendorreg.getLastName().length()<32)||(!vendorreg.getLastName().matches("[a-zA-Z ]+"))) {
			errors.rejectValue("lastName", null, "Enter Valid Last Name");
		}
		
		if(!vendorreg.getVendorId().matches("[a-zA-Z0-9]{6,14}")) {
			errors.rejectValue("vendorId", null, "Enter valid vendor Id");
		}
		
		if(!(vendorreg.getContactNumber().matches("^[789]\\d{9}$"))) {
			errors.rejectValue("contactNumber", null, "Please enter your 10 digit valid mobile number");
		}
		
		if(!(vendorreg.getPassword().matches("^(?=.*\\d)(?=.*[A-Z])(?=.*[a-z])(?=.*[^\\w\\d\\s:])([^\\s]){8,16}$"))) {
		   errors.rejectValue("password", null, "Enter valid password with minimum 6 characters with at least an uppercase character, a special symbol, a digit and a lowercase character");	
		}
		
		if(!(vendorreg.getAge() >=18) || !(vendorreg.getAge() < 99)) {
			errors.rejectValue("age", null, "Enter your original age");
		}
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "Enter Valid Password");
	}

}
