package com.carservice.validator;


import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.carservice.model.Register;


@Component
public class UserAndAdminRegistrationValidator implements Validator{


	@Override
	public boolean supports(Class<?> reg) {
		// TODO Auto-generated method stub
		return Register.class.equals(reg);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		Register reg = (Register)target;
		
		
		if(!(reg.getFirstName().length() > 2 && reg.getFirstName().length()<32) ||(!reg.getFirstName().matches("[a-zA-Z ]+"))) {
			errors.rejectValue("firstName", null, "Enter Valid First Name");
			
		}
		
		
		if(!(reg.getLastName().length() > 0) || !(reg.getLastName().length()<32)||(!reg.getLastName().matches("[a-zA-Z ]+"))) {
			errors.rejectValue("lastName", null, "Enter Valid Last Name");
		}
		
		if(!reg.getEmail().matches("([\\w.-]+@([\\w-]+)\\.+\\w{2,})")) {
			errors.rejectValue("email", null, "Enter Valid Email");
		}
		
		if(!(reg.getContactNumber().matches("^[789]\\d{9}$"))) {
			errors.rejectValue("contactNumber", null, "Please enter your 10 digit valid mobile number");
		}
		
		if(!(reg.getPassword().matches("^(?=.*\\d)(?=.*[A-Z])(?=.*[a-z])(?=.*[^\\w\\d\\s:])([^\\s]){8,16}$"))) {
		   errors.rejectValue("password", null, "Enter valid password with minimum 6 characters with at least an uppercase character, a special symbol, a digit and a lowercase character");	
		}
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "Enter Valid Password");
	 
	}

}
