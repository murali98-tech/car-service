package com.carservice.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carserive.dao.LoginDAO;
import com.carservice.model.Login;
import com.carservice.service.LoginValidator;
@Service
public class LoginValidatorImpl implements LoginValidator {

	@Autowired
	LoginDAO ldao;
	@Override
	public String validateUser(Login login) {
		
		return ldao.validateUser(login);
	}
	@Override
	public String validateVendorStatus(Login login) {
		// TODO Auto-generated method stub
		return ldao.validateVendorStatus(login);
	}
	

}
