package com.carservice.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.carservice.model.ServiceCenterDetails;

@Component
public class ServiceCenterValidator implements Validator{

	@Override
	public boolean supports(Class<?> center) {
		// TODO Auto-generated method stub
		return ServiceCenterDetails.class.equals(center);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		ServiceCenterDetails serviceCenter = (ServiceCenterDetails)target;
		System.out.println(serviceCenter.getServiceType().length);
		if(serviceCenter.getServiceType().length==0) {
			errors.rejectValue("serviceTypes", null, "Choose a service type");
		}
		
	}

}