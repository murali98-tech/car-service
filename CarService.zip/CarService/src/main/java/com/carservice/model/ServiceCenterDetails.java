package com.carservice.model;

import java.sql.Time;
import java.time.LocalTime;

import org.springframework.format.annotation.DateTimeFormat;

public class ServiceCenterDetails {
	private int centerId;
	private String name;
	private  String[] serviceTypes;
	private String location;
	@DateTimeFormat(iso = DateTimeFormat.ISO.TIME) 
	private LocalTime startTime;
	@DateTimeFormat(iso = DateTimeFormat.ISO.TIME) 
	private LocalTime endTime;
	private String contactNumber;
	private String Address;
	private double lat;
	private double lon;
	
	public int getCenterId() {
		return centerId;
	}
	public void setCenterId(int centerId) {
		this.centerId = centerId;
	}
	
	public ServiceCenterDetails() {
		super();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String[] getServiceType() {
		return serviceTypes;
	}
	public void setServiceType(String[] serviceType) {
		this.serviceTypes = serviceType;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public LocalTime getStartTime() {
		return startTime;
	}
	public void setStartTime(LocalTime time) {
		this.startTime = time;
	}
	public LocalTime getEndTime() {
		return endTime;
	}
	public void setEndTime(LocalTime time) {
		this.endTime = time;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public double getLat() {
		return lat;
	}
	public void setLat(double lat) {
		this.lat = lat;
	}
	public double getLon() {
		return lon;
	}
	public void setLon(double lon) {
		this.lon = lon;
	}
	
}
