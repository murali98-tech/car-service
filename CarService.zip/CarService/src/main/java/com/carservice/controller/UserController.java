package com.carservice.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.carserive.dao.SearchDAOImpl;
import com.carserive.dao.ServiceCenterDAO;
import com.carservice.model.BookService;
import com.carservice.model.Search;
@Controller
public class UserController {
      @Autowired
	  SearchDAOImpl searchResult;
      @Autowired
      ServiceCenterDAO center;
      @Autowired
		Search search2;
      @RequestMapping(value="/userHome",method=RequestMethod.GET)
  	public String userHome(Model model,HttpSession session) {
  		try {
  			if((!session.getAttribute("loginType").equals("user"))) {
  				return "redirect:/login";}}
  		    catch (Exception e) {
  		    	return "redirect:/login";
  			}
  	
  		return"userHome";
  	}
	@RequestMapping(value="/viewCenter",method=RequestMethod.GET)
	public String viewServiceCenter(@ModelAttribute("map")Search search,ModelMap model,HttpSession session) {
		 try {
				if((!session.getAttribute("loginType").equals("user"))) {
					return "redirect:/login";}}
			    catch (Exception e) {
			    	return "redirect:/login";
				}
		search2.setSearch("");
		search2.setServiceCenter("");
		System.out.println(searchResult.searchDatabase(search2).toString());
		model.addAttribute("searchList", searchResult.searchDatabase(search2));
		return"serviceCentersDisplay";
	}
	@RequestMapping(value="/searchCenter",method=RequestMethod.GET)
	public String searchServiceCenter(@ModelAttribute("map")Search search,ModelMap model,HttpSession session) {
		try {
			if((!session.getAttribute("loginType").equals("user"))) {
				return "redirect:/login";}}
		    catch (Exception e) {
		    	return "redirect:/login";
			}
	
		model.addAttribute("searchList", searchResult.searchDatabase(search));
		return"searchResult";
	}
	@RequestMapping(value="/serviceCenter",method=RequestMethod.GET)
	public String displayServiceCenterDetails(@ModelAttribute("map") Search search, @RequestParam("id") String id,ModelMap model,HttpSession session) {
		try {
			if((!session.getAttribute("loginType").equals("user"))) {
				return "redirect:/login";}}
		    catch (Exception e) {
		    	return "redirect:/login";
			}
		model.addAttribute("serviceCenter", center.searchForCenter(Integer.parseInt(id)));
		return "serviceCenterDetails";
	}
	@RequestMapping(value="/bookService",method=RequestMethod.GET)
	public String bookService(@ModelAttribute("book")BookService book,HttpSession session) {
		try {
			if((!session.getAttribute("loginType").equals("user"))) {
				return "redirect:/login";}}
		    catch (Exception e) {
		    	return "redirect:/login";
			}
		return "book";
		
	}
}
