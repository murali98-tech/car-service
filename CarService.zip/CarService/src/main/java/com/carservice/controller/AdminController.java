package com.carservice.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.carserive.dao.VendorRegistrationDAOImpl;
import com.carservice.model.VendorRegistration;
@Controller
public class AdminController {
	@Autowired
    private VendorRegistrationDAOImpl vendorList;
	@RequestMapping(value="/adminHome",method=RequestMethod.GET)
	public String adminHome(Model model,HttpSession session) {
		
	    try {
		if((!session.getAttribute("loginType").equals("admin"))) {
			System.out.println(12);
			return "redirect:/login";}}
	    catch (Exception e) {
	    	System.out.println(13);
	    	return "redirect:/login";
		}
		List <VendorRegistration>approvalList=vendorList.getPendingVendorsList();
		model.addAttribute("list",approvalList);
		
		return "admin";
		
		
	}
	@RequestMapping(value="/approve",method=RequestMethod.GET)
	public String approve(@RequestParam("id")int id,HttpSession session) {
		 try {
				if((!session.getAttribute("loginType").equals("admin"))) {
					return "redirect:/login";}}
			    catch (Exception e) {
			    	return "redirect:/login";
				}
		vendorList.approveVendor(id);
		
		return "redirect:adminHome";
	}
	@RequestMapping(value="/reject",method=RequestMethod.GET)
	public String reject(@RequestParam("id")int vendorId,HttpSession session) {
		try {
			if((!session.getAttribute("loginType").equals("admin"))) {
				return "redirect:/login";}}
		    catch (Exception e) {
		    	return "redirect:/login";
			}
		vendorList.rejectVendor(vendorId);
		return "redirect:adminHome";
	}
	
}
