package com.carservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.carserive.dao.RegistrationDAOImpl;
import com.carserive.dao.VendorRegistrationDAOImpl;
import com.carservice.model.Register;
import com.carservice.model.VendorRegistration;
import com.carservice.validator.UserAndAdminRegistrationValidator;
import com.carservice.validator.VendorRegistrationValidator;
@Controller
public class RegistrationController {
	
	private String type="";
	@Autowired
	private UserAndAdminRegistrationValidator userValidator;
	@Autowired
	private VendorRegistrationValidator VendorValidator; 
	@Autowired
	private RegistrationDAOImpl rdao;
	@Autowired
	private VendorRegistrationDAOImpl vdao;
	@RequestMapping(value= "/registeruser",method=RequestMethod.POST)
	public String RegisterUser(@ModelAttribute("details")Register register,BindingResult result,ModelMap model) {
		String message;
		userValidator.validate(register, result);
		if(result.hasErrors())
		{
    	return "registration";
		}
		boolean isInserted = rdao.adduser(register, type);
		if(isInserted == true)
		return "redirect:login";
		else {
			message="email id already exsist";
			model.addAttribute("message",message);
			return "registration";
		}
	}
	@RequestMapping(value= "/registeruser",method=RequestMethod.GET)
	public String RegisterUsr()  {
		throw new RuntimeException("not found");
		
	}
	@RequestMapping(value="/userRegistration",method=RequestMethod.GET)
	public String RegisterUserPage(@ModelAttribute("details")Register register) {
		this.type="user";
		return "registration";
	}
	@RequestMapping(value="/userRegistration",method=RequestMethod.POST)
	public String RegisterUserPag() {
		throw new RuntimeException("not found");
	}
	
	@RequestMapping(value="/adminRegistration",method=RequestMethod.POST)
	public String RegisterAdminPag(@ModelAttribute("details")Register register) {
		throw new RuntimeException("not found");
	}
	@RequestMapping(value="/adminRegistration",method=RequestMethod.GET)
	public String RegisterAdminPage(@ModelAttribute("details")Register register) {
		this.type="admin";
		return "registration";
	}
	@RequestMapping(value="/registervendor",method=RequestMethod.POST)
	public String RegisterVendor(@ModelAttribute("vendordetails")VendorRegistration vendor,BindingResult result) {
		VendorValidator.validate(vendor, result);
		if(result.hasErrors())
		{
    	return "vendorRegistration";
		}
		System.out.println("yes");
		boolean isRegister = vdao.addVendor(vendor);
		if(isRegister == true)
		return	"redirect:/login";


	return "registration";
		

	}
	@RequestMapping(value="/registervendor",method=RequestMethod.GET)
	public String RegisterVendordummy() {
		throw new RuntimeException("not found");
	}
	@RequestMapping(value="/vendorRegistration",method=RequestMethod.GET)
	public String RegisterVendorPage(@ModelAttribute("vendordetails")VendorRegistration vendor) {
		this.type="vendor";
		return "vendorRegistration";
	}
	@RequestMapping(value="/vendorRegistration",method=RequestMethod.POST)
	public String RegisterVend() {
		throw new RuntimeException("not found");
		
	}

}
