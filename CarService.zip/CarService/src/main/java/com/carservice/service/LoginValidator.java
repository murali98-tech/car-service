package com.carservice.service;

import org.springframework.stereotype.Service;

import com.carservice.model.Login;
@Service
public interface LoginValidator {
 public String validateUser(Login login);
 public String validateVendorStatus(Login login);
}
