package com.carserive.dao;

import org.springframework.stereotype.Service;

import com.carservice.model.ServiceCenterDetails;
@Service
public interface VendorServiceCenterDAO {
	public boolean addCenter(ServiceCenterDetails serviceCenterdetails,int vend_id);


}
