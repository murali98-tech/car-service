package com.carserive.dao;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.carservice.model.Search;
import com.carservice.model.ServiceCenterDetails;

@Service
public class SearchDAOImpl implements SearchDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	private final String slocation = "SELECT * from service_center_details where location=?";
	private final String swhole = "SELECT * from service_center_details";
	
	@Override
	public ArrayList<ServiceCenterDetails> searchDatabase(Search search) {
		String type = search.getServiceCenter();
		String name = search.getSearch();
		ArrayList<ServiceCenterDetails> li = new ArrayList<>();
		if(type.equals("Name")) {
			li = (ArrayList<ServiceCenterDetails>) jdbcTemplate.query("SELECT * from service_center_details where name LIKE '%"+name+"%'", new ServiceCenterDetailsMapper());
		}
		else if(type.equals("Type")) {
			li = (ArrayList<ServiceCenterDetails>) jdbcTemplate.query("SELECT * from service_center_details where servicetype LIKE '%"+name+"%'", new ServiceCenterDetailsMapper());
		}
		else if(type.equals("Location")){
			li = (ArrayList<ServiceCenterDetails>) jdbcTemplate.query(slocation,new Object[] {name}, new ServiceCenterDetailsMapper());
		}
		else {
			li = (ArrayList<ServiceCenterDetails>) jdbcTemplate.query(swhole, new ServiceCenterDetailsMapper());
		}
		return li;
	}

}
