package com.carserive.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.carservice.model.Login;

@Service
public class LoginDAOImpl implements LoginDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public String validateUser(Login login) {

		String userId = login.getUserId();

		String password = login.getPassword();

		String res;

		String sql1 = "SELECT User_id FROM USER_DETAILS WHERE EMAIL='" + userId + "' AND PASSWORD='" + password + "'";

		String sql2 = "SELECT vend_id FROM VENDOR_DETAILS WHERE VENDOR_ID = '" + userId + "' AND PASSWORD = '" + password + "'";
		//
		try {
//			System.out.println(login.getUserId());
//			System.out.println("inside try block");
			res = (String) jdbcTemplate.queryForObject(
					sql1, new Object[] {},
					String.class);
			System.out.println(res);
			String type = jdbcTemplate.queryForObject("SELECT usertype FROM USER_DETAILS WHERE EMAIL='" + userId + "' AND PASSWORD='" + password + "'",
					new Object[] { }, String.class);
			System.out.println(type);
			return res + "," + type;

		} catch (Exception e) {
//			System.out.println(e);
			try {
				res = jdbcTemplate.queryForObject(sql2, new Object[] {},
						String.class);
				System.out.println(res);
				return res + ",vendor";
			} catch (Exception E) {
				//System.out.println(E);
				return null;
			}
		}
	

	}

	@Override
	public String validateVendorStatus(Login login) {
		
		String userId = login.getUserId();
		String sql = "select approved_status from vendor_details where vendor_id='" + userId + "'";
		String status = (String)jdbcTemplate.queryForObject(sql, new Object[] { },
				String.class);
		return status;
	}

}
