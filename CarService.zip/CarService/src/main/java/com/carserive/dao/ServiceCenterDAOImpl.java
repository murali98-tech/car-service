package com.carserive.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.apache.logging.log4j.message.StringFormattedMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.stereotype.Service;

import com.carservice.model.ServiceCenterDetails;
import com.carservice.rowmapper.CenterRowMapper;
import com.carservice.rowmapper.ServiceCenterMapper;

@Service
public class ServiceCenterDAOImpl implements ServiceCenterDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public ServiceCenterDetails searchForCenter(int centerId) {
		ServiceCenterDetails scd = jdbcTemplate.queryForObject("SELECT * from service_center_details where center_id=?",
				new Object[] { centerId }, new ServiceCenterDetailsMapper());
		return scd;
	}

	private final String INSERT_SERVICE_CENTER = "INSERT INTO service_center_details(name,servicetype,location,start_time,end_time,phonenumber,address,latitude,longitude,vend_id)values(?,?,?,?,?,?,?,?,?,?)";
	private final String UPDATE_SERVICE_CENTER = "UPDATE SERVICE_CENTER_DETAILS SET NAME = ?,SERVICETYPE = ?,LOCATION = ?,START_TIME =?,END_TIME = ?,PHONENUMBER= ?,ADDRESS = ?,LATITUDE = ?,LONGITUDE = ? WHERE CENTER_ID = ?";
	private final String DELETE_SERVICE_CENTER = "DELETE FROM SERVICE_CENTER_DETAILS WHERE CENTER_ID=?";
	public boolean addCenter(ServiceCenterDetails serviceCenterDetails, int vend_id) {
		// System.out.println(vend_id);
		try {
			jdbcTemplate.update(new PreparedStatementCreator() {
				@Override
				public PreparedStatement createPreparedStatement(Connection connection) {
					try {
						PreparedStatement ps = connection.prepareStatement(INSERT_SERVICE_CENTER,
								Statement.RETURN_GENERATED_KEYS);
						String serviceTypes[] = serviceCenterDetails.getServiceType();
						String services = "";
						for (int index = 0; index < serviceTypes.length; index++) {
							if (index != serviceTypes.length - 1)
								services = services + serviceTypes[index] + ",";
							else
								services = services + serviceTypes[index];
						}
						ps.setString(1, serviceCenterDetails.getName());
						ps.setString(2, services);
						ps.setString(3, serviceCenterDetails.getLocation());
						ps.setTime(4, java.sql.Time.valueOf(serviceCenterDetails.getStartTime()));
						ps.setTime(5, java.sql.Time.valueOf(serviceCenterDetails.getEndTime()));
						ps.setString(6, serviceCenterDetails.getContactNumber());
						ps.setString(7, serviceCenterDetails.getAddress());
						ps.setDouble(8, serviceCenterDetails.getLat());
						ps.setDouble(9, serviceCenterDetails.getLon());
						ps.setInt(10, vend_id);
						return ps;

					} catch (NumberFormatException | SQLException e) {
						System.out.println(e.getMessage());
					}
					return null;
				}
			});
			return true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return false;
	}

	@Override
	public List<ServiceCenterDetails> getAllServiceCentersList(int vend_id) {
		List<ServiceCenterDetails> services = null;
		try {
			services = jdbcTemplate.query("select * from service_center_details where vend_id = ?",
					new ServiceCenterMapper(), vend_id);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return services;
	}

	@Override
	public ServiceCenterDetails findcenterById(int id) {
		String sql = "SELECT * FROM SERVICE_CENTER_DETAILS WHERE CENTER_ID = ?";
		return jdbcTemplate.queryForObject(sql, new Object[] { id }, new CenterRowMapper());
	}

	@Override
	public boolean updateCenter(ServiceCenterDetails serviceCenterDetails, int id) {

		try {
			jdbcTemplate.update(new PreparedStatementCreator() {
				@Override
				public PreparedStatement createPreparedStatement(Connection connection) {
					try {
						PreparedStatement ps = connection.prepareStatement(UPDATE_SERVICE_CENTER,
								Statement.RETURN_GENERATED_KEYS);
						String serviceTypes[] = serviceCenterDetails.getServiceType();
						String services = "";
						for (int index = 0; index < serviceTypes.length; index++) {
							if (index != serviceTypes.length - 1)
								services = services + serviceTypes[index] + ",";
							else
								services = services + serviceTypes[index];
						}
						ps.setString(1, serviceCenterDetails.getName());
						ps.setString(2, services);
						ps.setString(3, serviceCenterDetails.getLocation());
						ps.setTime(4, java.sql.Time.valueOf(serviceCenterDetails.getStartTime()));
						ps.setTime(5, java.sql.Time.valueOf(serviceCenterDetails.getEndTime()));
						ps.setString(6, serviceCenterDetails.getContactNumber());
						ps.setString(7, serviceCenterDetails.getAddress());
						ps.setDouble(8, serviceCenterDetails.getLat());
						ps.setDouble(9, serviceCenterDetails.getLon());
						ps.setInt(10, id);
						return ps;

					} catch (NumberFormatException | SQLException e) {
						System.out.println(e.getMessage());
					}
					return null;
				}
			});
			return true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return false;
	}

	@Override
	public boolean deleteCenter(int id) {
		try {
			jdbcTemplate.update(new PreparedStatementCreator() {
				@Override
				public PreparedStatement createPreparedStatement(Connection connection) {
					try {
						PreparedStatement ps = connection.prepareStatement(DELETE_SERVICE_CENTER,
								Statement.RETURN_GENERATED_KEYS);
						ps.setInt(1, id);
						return ps;

					} catch (NumberFormatException | SQLException e) {
						System.out.println(e.getMessage());
					}
					return null;
				}
			});
			return true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return false;
	}

}
