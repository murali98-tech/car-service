package com.carserive.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.stereotype.Service;

import com.carservice.model.ServiceCenterDetails;
@Service
public class VendorServiceCenterDAOImpl implements VendorServiceCenterDAO{

	@Autowired
	private JdbcTemplate jdbcTemplate;
	private final String INSERT_SERVICE_CENTER = "INSERT INTO service_center_details(name,servicetype,location,start_time,end_time,phonenumber,address,latitude,longitude,vend_id)values(?,?,?,?,?,?,?,?,?,?)";

	public boolean addCenter(ServiceCenterDetails serviceCenterDetails, int vend_id) {
		//System.out.println(vend_id);
		try {
			jdbcTemplate.update(new PreparedStatementCreator() {
				@Override
				public PreparedStatement createPreparedStatement(Connection connection) {
					try {
						PreparedStatement ps = connection.prepareStatement(INSERT_SERVICE_CENTER,
								Statement.RETURN_GENERATED_KEYS);
						String serviceTypes[] = serviceCenterDetails.getServiceType();
						String services = "";
						for (int index = 0; index < serviceTypes.length; index++) {
							if (index != serviceTypes.length - 1)
								services = services + serviceTypes[index] + ",";
							else
								services = services + serviceTypes[index];
						}
						ps.setString(1, serviceCenterDetails.getName());
						ps.setString(2, services);
						ps.setString(3, serviceCenterDetails.getLocation());
						ps.setTime(4, java.sql.Time.valueOf(serviceCenterDetails.getStartTime()));
						ps.setTime(5, java.sql.Time.valueOf(serviceCenterDetails.getEndTime()));
						ps.setString(6, serviceCenterDetails.getContactNumber());
						ps.setString(7, serviceCenterDetails.getAddress());
						ps.setDouble(8, serviceCenterDetails.getLat());
						ps.setDouble(9, serviceCenterDetails.getLon());
						ps.setInt(10, vend_id);
						return ps;

					} catch (NumberFormatException | SQLException e) {
						System.out.println("inside try 1");
						System.out.println(e.getMessage());
					}
					return null;
				}
			});
			return true;
		} catch (Exception e) {
			System.out.println("inside try 2");
			System.out.println(e.getMessage());
		}
		return false;
	}

}
