package com.carserive.dao;

import java.util.ArrayList;

import com.carservice.model.Search;
import com.carservice.model.ServiceCenterDetails;

public interface SearchDAO {
	public ArrayList<ServiceCenterDetails> searchDatabase(Search search);
}
