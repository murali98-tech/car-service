CREATE TABLE IF NOT EXISTS `user_details` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `contactnumber` mediumtext NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  PRIMARY KEY (`user_id`)
);


CREATE TABLE IF NOT EXISTS `vendor_details` (
  `vend_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `contactnumber` bigint(20) NOT NULL,
  `vendor_id` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `Approved_status` varchar(20) NOT NULL,
  PRIMARY KEY (`vend_id`)
);


CREATE TABLE IF NOT EXISTS `service_center_details` (
  `center_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `location` varchar(20) NOT NULL,
  `phonenumber` bigint(20) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `servicetype` varchar(20) NOT NULL,
  `latitude` float(10,8) NOT NULL,
  `longitude` float(11,8) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `vend_id` int(11) NOT NULL,
  PRIMARY KEY (`center_id`),
  KEY `userId_idx` (`user_id`),
  KEY `vend_id_idx` (`vend_id`),
  CONSTRAINT `vend_id` FOREIGN KEY (`vend_id`) REFERENCES `vendor_details` (`vend_id`)
);




CREATE TABLE IF NOT EXISTS `bookservice` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `vend_id` int(11) NOT NULL,
  `user_address` varchar(100) DEFAULT NULL,
  `approved_status` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `center_id` int(11) NOT NULL,
  PRIMARY KEY (`book_id`),
  KEY `user_id_idx` (`user_id`),
  KEY `vend_id_idx` (`vend_id`),
  KEY `center_id_idx` (`center_id`),
  CONSTRAINT `center-id` FOREIGN KEY (`center_id`) REFERENCES `service_center_details` (`center_id`),
  CONSTRAINT `user-id` FOREIGN KEY (`user_id`) REFERENCES `user_details` (`user_id`),
  CONSTRAINT `vend-id` FOREIGN KEY (`vend_id`) REFERENCES `vendor_details` (`vend_id`)
);



CREATE TABLE IF NOT EXISTS `bill_details` (
  `Bill_id` int(11) NOT NULL AUTO_INCREMENT,
  `Amount` double NOT NULL,
  `paymenttype` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `vend_id` int(11) NOT NULL,
  `center_id` int(11) NOT NULL,
  PRIMARY KEY (`Bill_id`),
  KEY `us_id_idx` (`user_id`),
  KEY `ven_id_idx` (`vend_id`),
  KEY `cen_id_idx` (`center_id`),
  CONSTRAINT `cen_id` FOREIGN KEY (`center_id`) REFERENCES `service_center_details` (`center_id`),
  CONSTRAINT `us_id` FOREIGN KEY (`user_id`) REFERENCES `user_details` (`user_id`),
  CONSTRAINT `ven_id` FOREIGN KEY (`vend_id`) REFERENCES `vendor_details` (`vend_id`)
);




CREATE TABLE IF NOT EXISTS `feedback_report` (
  `center_id` int(11) NOT NULL,
  `feedback_id` int(11) NOT NULL Auto_Increment,
  `vendor_service` varchar(15) NOT NULL,
  `timing` varchar(15) NOT NULL,
  `service_provider` varchar(15) NOT NULL,
  `improvement` int(11) NOT NULL,
  `rating` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`feedback_id`),
  KEY `userid_idx` (`user_id`),
  CONSTRAINT `userid` FOREIGN KEY (`user_id`) REFERENCES `user_details` (`user_id`)
);

